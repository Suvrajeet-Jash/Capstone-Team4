from fastapi import APIRouter, HTTPException
from sqlalchemy.exc import SQLAlchemyError
from database import engine, Base

router = APIRouter(prefix="/setup", tags=["setup"])

@router.post("/create-tables")
def create_tables():
    try:
        Base.metadata.create_all(bind=engine)
        return {"message": "Tables created successfully"}
    except SQLAlchemyError as e:
        raise HTTPException(status_code=500, detail=f"Failed to create tables: {str(e)}")
