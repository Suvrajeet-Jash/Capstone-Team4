from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import crud, database, schemas

router = APIRouter(prefix="/shipments", tags=["shipments"])

@router.post("/log", status_code=201)
def log_shipment(shipment: schemas.ShipmentCreate, db: Session = Depends(database.get_db)):
    # Optionally check for duplicates
    existing = db.query(database.Base.metadata.tables['shipments']).filter_by(shipment_id=shipment.shipment_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Shipment with this ID already exists")
    return crud.create_shipment(db, shipment)
