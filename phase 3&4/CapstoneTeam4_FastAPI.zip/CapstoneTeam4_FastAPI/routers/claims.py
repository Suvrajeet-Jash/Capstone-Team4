from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
import crud, database, schemas

router = APIRouter(prefix="/claims", tags=["claims"])

# @router.get("/summary", response_model=list[schemas.ClaimSummary])
# def claims_summary(db: Session = Depends(database.get_db)):
#     return crud.get_claims_summary_by_status(db)
@router.get("/claims/summary", response_model=list[schemas.ClaimStatusSummary])
def get_claims_summary_by_status(db: Session = Depends(database.get_db)):
    return crud.get_claims_summary_by_status(db)
