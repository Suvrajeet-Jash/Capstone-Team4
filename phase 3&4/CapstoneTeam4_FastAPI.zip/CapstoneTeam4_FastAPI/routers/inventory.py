from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
import crud, database, schemas

router = APIRouter(prefix="/inventory", tags=["inventory"])

@router.get("/health", response_model=list[schemas.InventoryHealthItem])
def inventory_health(db: Session = Depends(database.get_db)):
    return crud.get_inventory_health(db)
