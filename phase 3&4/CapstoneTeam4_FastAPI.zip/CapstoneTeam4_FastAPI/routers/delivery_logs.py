from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import DataError  # ✅ import DataError
import csv
import io
import database, models
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/delivery-logs", tags=["delivery-logs"])


@router.post("/upload")
async def upload_delivery_logs(file: UploadFile = File(...), db: Session = Depends(database.get_db)):
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files allowed")

    content = await file.read()
    content_str = content.decode("utf-8")
    reader = csv.DictReader(io.StringIO(content_str))

    rows_added = 0
    rows_updated = 0
    errors = []

    for i, row in enumerate(reader, start=1):
        try:
            # Check if delivery_id already exists
            existing_log = db.query(models.DeliveryLog).filter_by(delivery_id=str(row["delivery_id"])).first()

            if existing_log:
                # Update existing record
                existing_log.shipment_id = str(row["shipment_id"])
                existing_log.carrier = row["carrier"]
                existing_log.status = row["status"]
                existing_log.delivery_duration_days = int(row["delivery_duration_days"])
                existing_log.damage_flag = row["damage_flag"].lower() == "true"
                existing_log.proof_of_delivery_status = row["proof_of_delivery_status"]
                rows_updated += 1
            else:
                # Insert new record
                delivery_log = models.DeliveryLog(
                    delivery_id=str(row["delivery_id"]),
                    shipment_id=str(row["shipment_id"]),
                    carrier=row["carrier"],
                    status=row["status"],
                    delivery_duration_days=int(row["delivery_duration_days"]),
                    damage_flag=row["damage_flag"].lower() == "true",
                    proof_of_delivery_status=row["proof_of_delivery_status"]
                )
                db.add(delivery_log)
                rows_added += 1

        except DataError as e:
            db.rollback()  # rollback the bad transaction
            error_msg = f"Row {i}: Data too long or invalid for DB column - {str(e.orig)}"
            logger.error(error_msg)
            errors.append({
                "row": i,
                "error": "DataError",
                "details": f"Invalid data for database column: {str(e.orig)}"
            })

        except Exception as e:
            db.rollback()
            error_msg = f"Row {i}: {str(e)}"
            logger.error(error_msg)
            errors.append({
                "row": i,
                "error": str(e),
                "details": f"Failed to process delivery log with shipment_id {row.get('shipment_id', 'N/A')}"
            })

    try:
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"Commit failed: {e}")
        errors.append({
            "row": "ALL",
            "error": "CommitError",
            "details": f"Failed to commit changes: {str(e)}"
        })

    response = {"message": f"Uploaded {rows_added} new delivery logs, updated {rows_updated} existing logs"}
    if errors:
        response["errors"] = errors

    return response
