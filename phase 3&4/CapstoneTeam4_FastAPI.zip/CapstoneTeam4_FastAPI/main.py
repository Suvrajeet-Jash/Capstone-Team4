from fastapi import FastAPI
from database import engine, Base
from routers import claims, inventory, shipments, delivery_logs, setup

app = FastAPI(title="Supply Chain Capstone Team4")

# Base.metadata.create_all(bind=engine)

app.include_router(claims.router)
app.include_router(inventory.router)
app.include_router(shipments.router)
app.include_router(delivery_logs.router)
app.include_router(setup.router)