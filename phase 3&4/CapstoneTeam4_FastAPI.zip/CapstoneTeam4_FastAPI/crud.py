from sqlalchemy.orm import Session
from sqlalchemy import func
import models, schemas

def get_claims_summary(db: Session) -> list[schemas.ClaimSummary]:
    deliveries_subq = db.query(
        models.DeliveryLog.carrier,
        func.count(models.DeliveryLog.delivery_id).label("total_deliveries")
    ).group_by(models.DeliveryLog.carrier).subquery()

    claims_subq = db.query(
        models.DeliveryLog.carrier,
        func.count(models.Claim.claim_id).label("claim_count")
    ).join(models.Claim, models.DeliveryLog.delivery_id == models.Claim.delivery_id)\
    .group_by(models.DeliveryLog.carrier).subquery()

    query = db.query(
        deliveries_subq.c.carrier,
        deliveries_subq.c.total_deliveries,
        func.coalesce(claims_subq.c.claim_count, 0).label("claim_count")
    ).outerjoin(
        claims_subq, deliveries_subq.c.carrier == claims_subq.c.carrier
    )

    results = []
    for row in query.all():
        claim_percentage = (row.claim_count / row.total_deliveries * 100) if row.total_deliveries > 0 else 0
        results.append(
            schemas.ClaimSummary(
                carrier=row.carrier,
                total_deliveries=row.total_deliveries,
                claim_count=row.claim_count,
                claim_percentage=round(claim_percentage, 2)
            )
        )
    return results

def get_claims_summary_by_status(db: Session) -> list[schemas.ClaimStatusSummary]:
    """
    Summarize claims by carrier and claim status
    (e.g., how many approved/rejected/pending claims per carrier).
    """

    query = (
        db.query(
            models.DeliveryLog.carrier,
            models.Claim.claim_status,
            func.count(models.Claim.claim_id).label("claim_count"),
            func.sum(models.Claim.amount_claimed).label("total_claimed")
        )
        .join(models.Claim, models.DeliveryLog.delivery_id == models.Claim.delivery_id)
        .group_by(models.DeliveryLog.carrier, models.Claim.claim_status)
    )

    results = []
    for row in query.all():
        results.append(
            schemas.ClaimStatusSummary(
                carrier=row.carrier,
                claim_status=row.claim_status,
                claim_count=row.claim_count,
                total_claimed=float(row.total_claimed or 0)
            )
        )
    return results

def get_inventory_health(db: Session) -> list[schemas.InventoryHealthItem]:
    items = db.query(models.Inventory).all()
    response = []
    for item in items:
        needs_reorder = item.stock_level <= item.reorder_threshold
        response.append(
            schemas.InventoryHealthItem(
                warehouse_id=item.warehouse_id,
                product_id=item.product_id,
                stock_level=item.stock_level,
                reorder_threshold=item.reorder_threshold,
                needs_reorder=needs_reorder
            )
        )
    return response

def create_shipment(db: Session, shipment: schemas.ShipmentCreate):
    db_shipment = models.Shipment(**shipment.dict())
    db.add(db_shipment)
    db.commit()
    db.refresh(db_shipment)
    return db_shipment
