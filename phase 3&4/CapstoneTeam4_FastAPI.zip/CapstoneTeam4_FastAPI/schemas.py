from io import StringIO

from pydantic import BaseModel
from datetime import date
from typing import Optional, List

class ShipmentCreate(BaseModel):
    shipment_id: str
    origin_warehouse: str
    destination_city: str
    ship_date: date
    delivery_date: date
    product_id: str
    quantity: int
    freight_cost: float

class ClaimSummary(BaseModel):
    carrier: str
    total_deliveries: int
    claim_count: int
    claim_percentage: float

class ClaimStatusSummary(BaseModel):
    carrier: str
    claim_status: str
    claim_count: int
    total_claimed: float

class InventoryHealthItem(BaseModel):
    warehouse_id: str
    product_id: str
    stock_level: int
    reorder_threshold: int
    needs_reorder: bool
