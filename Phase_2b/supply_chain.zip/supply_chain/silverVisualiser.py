# Databricks notebook source
# Retrieve the secret value using the key name (replace with your secret's key)
access_key="3knoB6QmGx5y88uE0X17JMjGr80j0Irs/5ol/986kAudEkM+u2VeLIQLRdZhQtFjvIIJoRpdmHHr+AStbhLWVA=="

# Set Spark config to use the ADLS access key
spark.conf.set(
    "fs.azure.account.key.adlsteam4.dfs.core.windows.net",
    access_key
)

# Define the path to the raw container
adls_path = "abfss://silver@adlsteam4.dfs.core.windows.net/"

# # List all CSV file paths in the raw container
# csv_files = [f.path for f in dbutils.fs.ls(adls_path) if f.path.lower().endswith('.csv')]
# display(csv_files)

# COMMAND ----------

# Read the CSV files into Spark DataFrames

inventory_df = spark.read.format("delta").load("abfss://silver@adlsteam4.dfs.core.windows.net/inventory_df")
display(inventory_df)

merged_data_raw = spark.read.format("delta").load("abfss://silver@adlsteam4.dfs.core.windows.net/merged_data_raw")
display(merged_data_raw)

vendors_df = spark.read.format("delta").load("abfss://silver@adlsteam4.dfs.core.windows.net/vendors_df")
display(vendors_df)


delivery_logs_df = spark.read.format("delta").load("abfss://bronze@adlsteam4.dfs.core.windows.net/delivery_logs")
display(delivery_logs_df)

# COMMAND ----------

# making temporary views to be able to use the dataframes with sql

inventory_df.createOrReplaceTempView("inventory_df")
merged_data_raw.createOrReplaceTempView("merged_data_raw")
vendors_df.createOrReplaceTempView("vendors_df")
delivery_logs_df.createOrReplaceTempView("delivery_logs_df")

display(spark.sql("SHOW TABLES"))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM inventory_df;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT * FROM merged_data_raw;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM vendors_df;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Total freight cost and average claim amount by destination city
# MAGIC
# MAGIC SELECT 
# MAGIC   merged_data_raw.destination_city, 
# MAGIC   SUM(merged_data_raw.freight_cost) AS total_freight_cost, 
# MAGIC   AVG(merged_data_raw.amount_claimed) AS avg_claim_amount
# MAGIC FROM merged_data_raw
# MAGIC GROUP BY merged_data_raw.destination_city
# MAGIC ORDER BY merged_data_raw.destination_city
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Total freight cost and average claim amount by carrier name
# MAGIC
# MAGIC SELECT 
# MAGIC   merged_data_raw.carrier,
# MAGIC   merged_data_raw.product_id,
# MAGIC   COUNT(*) AS shipment_count,
# MAGIC   SUM(merged_data_raw.freight_cost) AS total_freight_cost,
# MAGIC   AVG(merged_data_raw.amount_claimed) AS avg_claim_amount
# MAGIC FROM merged_data_raw
# MAGIC LEFT JOIN vendors_df
# MAGIC   ON merged_data_raw.product_id = vendors_df.product_id
# MAGIC GROUP BY merged_data_raw.carrier, merged_data_raw.product_id
# MAGIC ORDER BY merged_data_raw.carrier
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- total freight cost and average claim amount by vendor name
# MAGIC
# MAGIC SELECT 
# MAGIC   vendors_df.vendor_name,
# MAGIC   merged_data_raw.product_id,
# MAGIC   COUNT(*) AS shipment_count,
# MAGIC   SUM(merged_data_raw.freight_cost) AS total_freight_cost,
# MAGIC   AVG(merged_data_raw.amount_claimed) AS avg_claim_amount
# MAGIC FROM merged_data_raw
# MAGIC JOIN vendors_df
# MAGIC   ON merged_data_raw.product_id = vendors_df.product_id
# MAGIC GROUP BY vendors_df.vendor_name, merged_data_raw.product_id
# MAGIC ORDER BY vendors_df.vendor_name

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- to calculate delays
# MAGIC
# MAGIC SELECT 
# MAGIC   DATE_TRUNC('month', delivery_date) AS month,
# MAGIC   AVG(delivery_duration_days) AS avg_delivery_duration,
# MAGIC   AVG(delivery_duration_days - 3) AS avg_delay_days -- 3 is example SLA
# MAGIC FROM merged_data_raw
# MAGIC GROUP BY month
# MAGIC ORDER BY month;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Calculate % of the delayed shipments
# MAGIC
# MAGIC SELECT 
# MAGIC   DATE_TRUNC('month', delivery_date) AS month,
# MAGIC   COUNT(CASE WHEN delivery_duration_days > 3 THEN 1 END) * 100.0 / COUNT(*) AS pct_delayed_shipments
# MAGIC FROM merged_data_raw
# MAGIC GROUP BY month
# MAGIC ORDER BY month;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     d.carrier,
# MAGIC     COUNT(*) AS delayed_shipments_count,
# MAGIC     AVG(d.delivery_duration_days) AS avg_delivery_duration,
# MAGIC     AVG(d.delivery_duration_days - 3) AS avg_delay_days
# MAGIC FROM merged_data_raw s
# MAGIC JOIN delivery_logs_df d ON s.shipment_id = d.shipment_id
# MAGIC WHERE d.delivery_duration_days > 3
# MAGIC GROUP BY d.carrier
# MAGIC ORDER BY delayed_shipments_count DESC;
# MAGIC