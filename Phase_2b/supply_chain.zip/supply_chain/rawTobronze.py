# Databricks notebook source
# Retrieve the secret value using the key name (replace with your secret's key)
access_key="3knoB6QmGx5y88uE0X17JMjGr80j0Irs/5ol/986kAudEkM+u2VeLIQLRdZhQtFjvIIJoRpdmHHr+AStbhLWVA=="

# Set Spark config to use the ADLS access key
spark.conf.set(
    "fs.azure.account.key.adlsteam4.dfs.core.windows.net",
    access_key
)

# Define the path to the raw container
adls_path = "abfss://raw@adlsteam4.dfs.core.windows.net/"

# List all CSV file paths in the raw container
csv_files = [f.path for f in dbutils.fs.ls(adls_path) if f.path.lower().endswith('.csv')]
display(csv_files)

# COMMAND ----------

claims_df = spark.read.format("csv").option("header", "true").load("abfss://raw@adlsteam4.dfs.core.windows.net/claims.csv")
display(claims_df)
delivery_logs_df = spark.read.format("csv").option("header", "true").load("abfss://raw@adlsteam4.dfs.core.windows.net/delivery_logs.csv")
display(delivery_logs_df)
inventory_df = spark.read.format("csv").option("header", "true").load("abfss://raw@adlsteam4.dfs.core.windows.net/inventory (1).csv")
display(inventory_df)
shipments_df = spark.read.format("csv").option("header", "true").load("abfss://raw@adlsteam4.dfs.core.windows.net/shipments.csv")
display(shipments_df)
vendors_df = spark.read.format("csv").option("header", "true").load("abfss://raw@adlsteam4.dfs.core.windows.net/vendors.csv")
display(vendors_df)

# COMMAND ----------

#processing data before sending it to bronze from raw

# COMMAND ----------

claims_df.write.format("delta").mode("overwrite").save("abfss://bronze@adlsteam4.dfs.core.windows.net/claims")

delivery_logs_df.write.format("delta").mode("overwrite").save("abfss://bronze@adlsteam4.dfs.core.windows.net/delivery_logs")

inventory_df.write.format("delta").mode("overwrite").save("abfss://bronze@adlsteam4.dfs.core.windows.net/inventory")
display(inventory_df)

shipments_df.write.format("delta").mode("overwrite").save("abfss://bronze@adlsteam4.dfs.core.windows.net/shipments")

vendors_df.write.format("delta").mode("overwrite").save("abfss://bronze@adlsteam4.dfs.core.windows.net/vendors")
