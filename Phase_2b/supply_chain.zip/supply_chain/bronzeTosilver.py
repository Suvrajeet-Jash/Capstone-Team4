# Databricks notebook source
# Retrieve the secret value using the key name (replace with your secret's key)
access_key="3knoB6QmGx5y88uE0X17JMjGr80j0Irs/5ol/986kAudEkM+u2VeLIQLRdZhQtFjvIIJoRpdmHHr+AStbhLWVA=="

# Set Spark config to use the ADLS access key
spark.conf.set(
    "fs.azure.account.key.adlsteam4.dfs.core.windows.net",
    access_key
)

# Define the path to the raw container
adls_path = "abfss://raw@adlsteam4.dfs.core.windows.net/"

# List all CSV file paths in the raw container
csv_files = [f.path for f in dbutils.fs.ls(adls_path) if f.path.lower().endswith('.csv')]
display(csv_files)

# COMMAND ----------

claims_df = spark.read.format("csv").option("header", "true").load("abfss://raw@adlsteam4.dfs.core.windows.net/claims.csv")
display(claims_df)

# COMMAND ----------

claims_df = spark.read.format("delta").load("abfss://bronze@adlsteam4.dfs.core.windows.net/claims")
display(claims_df)
delivery_logs_df = spark.read.format("delta").load("abfss://bronze@adlsteam4.dfs.core.windows.net/delivery_logs")
display(delivery_logs_df)
inventory_df = spark.read.format("delta").load("abfss://bronze@adlsteam4.dfs.core.windows.net/inventory")
display(inventory_df)
shipments_df = spark.read.format("delta").load("abfss://bronze@adlsteam4.dfs.core.windows.net/shipments")
display(shipments_df)
vendors_df = spark.read.format("delta").load("abfss://bronze@adlsteam4.dfs.core.windows.net/vendors")
display(vendors_df)

# COMMAND ----------

#processing data before sending it to silver from raw



# COMMAND ----------

#Merging shipment, delivery and claims

from pyspark.sql.functions import col

claim_del = claims_df.join(delivery_logs_df, on="delivery_id", how="left")
claim_del_ship = claim_del.join(shipments_df, on="shipment_id", how="left")
claim_del_ship_ven = claim_del_ship.join(vendors_df, on="product_id", how="left")
merged_data_raw = claim_del_ship_ven.join(inventory_df, on="product_id", how="left")

display(merged_data_raw)

# COMMAND ----------

merged_data_raw = merged_data_raw.dropDuplicates()
display(merged_data_raw)

# COMMAND ----------

from pyspark.sql.functions import col, datediff, when

# Calculate delay duration (in days)
merged_data_raw = merged_data_raw.withColumn(
    "delay_days",
    datediff(col("delivery_date"), col("ship_date"))
)

# Add reorder flag (1 if stock_level < reorder_threshold, else 0)
merged_data_raw = merged_data_raw.withColumn(
    "reorder_flag",
    when(col("stock_level") < col("reorder_threshold"), 1).otherwise(0)
)

# Calculate claim aging (resolved_date - claim_date, in days)
merged_data_raw = merged_data_raw.withColumn(
    "claim_aging_days",
    datediff(col("resolved_date"), col("claim_date"))
)

display(merged_data_raw)

# COMMAND ----------

merged_data_raw.write.format("delta").mode("overwrite").option("mergeSchema", "true").save("abfss://silver@adlsteam4.dfs.core.windows.net/merged_data_raw")

#delivery_logs_df.write.format("delta").mode("overwrite").save("abfss://silver@adlsteam4.dfs.core.windows.net/delivery_logs")

inventory_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").save("abfss://silver@adlsteam4.dfs.core.windows.net/inventory_df")
display(inventory_df)

#shipments_df.write.format("delta").mode("overwrite").save("abfss://silver@adlsteam4.dfs.core.windows.net/shipments")

vendors_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").save("abfss://silver@adlsteam4.dfs.core.windows.net/vendors_df")